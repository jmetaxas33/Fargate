
const config = {
  appId: "com.fargate.gateway",
  appName: "Fargate Gateway",
  webDir: "build",
  bundledWebRuntime: false
};

export default config;
